/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execute.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: kpanikka <kpanikka@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/11/03 17:42:15 by kpanikka          #+#    #+#             */
/*   Updated: 2022/12/13 13:23:46 by kpanikka         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	ft_exec(void)
{
	(void) g_msv;
	// if (g_msv.block_list->cmd_seq == 1)
	// 	ft_exec_echo(g_msv);
	// // if (g_msv.block_list->cmd_seq == 1)
	// 	ft_exec_export(g_msv);
	// else if (g_msv.block_list->content == 1)
	// 	ft_exec_pwd(g_msv);
	// if (g_msv.block_list->cmd_seq == 1)
	// 	ft_exec_env(g_msv);
}
// }