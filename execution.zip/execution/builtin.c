/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   builtin.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: skabeer <skabeer@student.42abudhabi.ae>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/12/15 14:27:34 by skabeer           #+#    #+#             */
/*   Updated: 2022/12/15 14:28:00 by skabeer          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"



void	pwdfn(t_cblock *tmp, t_env *env, t_msvar **mvar, int i)
{
	(void)tmp;
	(void)i;
	(void)mvar;
	printf("%s", ft_getenv("PWD", env));
	exit(1);
}

void	echo_fn(t_cblock *tmp, t_env *env, t_msvar **mvar, int i)
{
	(void)env;
	(void)mvar;
	(void)i;
	ft_putstr_fd(tmp->cmd[1], 1);
	ft_putchar_fd('\n', 1);
	exit(1);
}

int	cd_fn(t_cblock *tmp)
{
	if (chdir(ft_strtrim(tmp->cmd[1]," ")) != 0) 
		perror("cd error");
	return (0);
}

int	export_fn(t_cblock *tmp)
{
	export_env(ft_strtrim(tmp->cmd[1], " "), ft_strtrim(tmp->cmd[2], " "));
	return (1);
}

